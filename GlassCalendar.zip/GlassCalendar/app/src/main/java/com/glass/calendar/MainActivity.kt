package com.glass.calendar

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var insT = 0f
    private var insB = 0f
    private fun applyInsets() =
        web.evaluateJavascript("window.setInsets&&setInsets($insT,$insB)", null)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0
        window.navigationBarColor = 0
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        web = WebView(this)
        web.setBackgroundColor(0xFFF2F2F4.toInt())
        web.setOnApplyWindowInsetsListener { _, ins ->
            val d = resources.displayMetrics.density
            insT = ins.systemWindowInsetTop / d
            insB = ins.systemWindowInsetBottom / d
            applyInsets()
            ins
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { applyInsets() }
        }
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.loadUrl("file:///android_asset/index.html")
    }
}
